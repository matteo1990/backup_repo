#!/bin/bash

	echo -e "Da linea di comando hai inserito $# parametri\n";
	echo -e "Il programma in esecuzione è $0\n"
	echo -e "Il primo parametro inserito è $1\n"
	echo -e "I programmi inseriti sono $@\n"
