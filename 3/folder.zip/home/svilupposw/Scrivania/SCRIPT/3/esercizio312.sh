#!/bin/bash


zip -r folder.zip $1; 

echo -e "Ho eseguito il backup $1\n";

